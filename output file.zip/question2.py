class TrainingEvent:
    def __init__(self, event_id, event_name, date, duration_hours, location):
        self.event_id = event_id
        self.event_name = event_name
        self.date = date
        self.duration_hours = duration_hours
        self.location = location

class Staff:
    def __init__(self, staff_id, name, department):
        self.staff_id = staff_id
        self.name = name
        self.department = department
        self.training_history = []

    def attend_training(self, event):
        self.training_history.append(event)

class TrainingTracker:
    def __init__(self):
        self.training_events = []
        self.staff_records = {}

    def add_training_event(self, event):
        self.training_events.append(event)

    def add_staff(self, staff):
        self.staff_records[staff.staff_id] = staff

    def assign_training_to_staff(self, staff_id, event_id):
        if staff_id in self.staff_records and event_id in [event.event_id for event in self.training_events]:
            staff = self.staff_records[staff_id]
            event = next(event for event in self.training_events if event.event_id == event_id)
            staff.attend_training(event)
            print(f"{staff.name} attended the {event.event_name} training.")
        else:
            print("Invalid staff ID or event ID.")

    def display_staff_training_history(self, staff_id):
        if staff_id in self.staff_records:
            staff = self.staff_records[staff_id]
            print(f"Training History for {staff.name}:")
            for event in staff.training_history:
                print(f"Event ID: {event.event_id}, Event Name: {event.event_name}, Date: {event.date}, Duration: {event.duration_hours} hours, Location: {event.location}")
        else:
            print("Staff not found.")


# Example usage:

# Create training events
event1 = TrainingEvent(1, "Python Workshop", "2024-02-15", 4, "Online")
event2 = TrainingEvent(2, "Project Management Training", "2024-03-10", 6, "Office")

# Create staff members
staff1 = Staff(101, "John Doe", "IT Department")
staff2 = Staff(102, "Jane Smith", "HR Department")

# Create training tracker
tracker = TrainingTracker()

# Add training events to the tracker
tracker.add_training_event(event1)
tracker.add_training_event(event2)

# Add staff members to the tracker
tracker.add_staff(staff1)
tracker.add_staff(staff2)

# Assign training to staff
tracker.assign_training_to_staff(101, 1)
tracker.assign_training_to_staff(102, 2)

# Display staff training history
tracker.display_staff_training_history(101)
tracker.display_staff_training_history(102)
