class Staff:
    def __init__(self, name, age, qualification, roles, contact):
        self.name = name
        self.age = age
        self.qualification = qualification
        self.roles = roles
        self.contact = contact

class StaffManagementSystem:
    def __init__(self):
        self.staff_list = []

    def add_staff(self, staff):
        self.staff_list.append(staff)

    def display_staff_details(self):
        if self.staff_list:
            print("Staff Details:")
            for index, staff in enumerate(self.staff_list, start=1):
                print(f"\nStaff {index}:")
                print("Name:", staff.name)
                print("Age:", staff.age)
                print("Qualification:", staff.qualification)
                print("Roles:", ", ".join(staff.roles))
                print("Contact:", staff.contact)
        else:
            print("No staff records found.")

# Example usage:
staff_system = StaffManagementSystem()

# Add staff members
staff1 = Staff("John Doe", 30, "Bachelor's in Computer Science", ["Developer", "Team Lead"], "john@example.com")
staff2 = Staff("Jane Smith", 25, "Master's in Business Administration", ["Manager"], "jane@example.com")

staff_system.add_staff(staff1)
staff_system.add_staff(staff2)

# Display staff details
staff_system.display_staff_details()
