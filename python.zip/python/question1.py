class Staff:
    def __init__(self, name, age, qualification, roles, contact):
        self.name = name
        self.age = age
        self.qualification = qualification
        self.roles = roles
        self.contact = contact

class StaffManagementSystem:
    def __init__(self):
        self.staff_list = []

    def add_staff(self, staff):
        self.staff_list.append(staff)

    def display_staff_details(self):
        if self.staff_list:
            print("Staff Details:")
            for index, staff in enumerate(self.staff_list, start=1):
                print(f"\nStaff {index}:")
                print("Name:", staff.name)
                print("Age:", staff.age)
                print("Qualification:", staff.qualification)
                print("Roles:", ", ".join(staff.roles))
                print("Contact:", staff.contact)
        else:
            print("No staff records found.")