class staff:
    def _int_(self,name,conatct,age,role):
     self.name=Name
     self.contact=contact
     self.age=age
     self.role=role
class staffinformationsystem:
    def _int_(self):
         self.staff_list = []
    
    def _updates_(self,staff) :
        self.staff_list.append()
    def display_staff_informationupdates(self)
        if self.staff_list:
           print("staff information")
           for index,staff in enumerate(self.staff_list,start=1):
                print(f"\nstaff{index}:")
                print("Name:",staff.name)
                print("contact:",staff.contact)
                print("age:",staff.age)
        else:
                print("No updates for staff information.")
                
                      
