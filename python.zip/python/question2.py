class TrainingEvent:
    def __init__(self, event_id, event_name, date, duration_hours, location):
        self.event_id = event_id
        self.event_name = event_name
        self.date = date
        self.duration_hours = duration_hours
        self.location = location

class Staff:
    def __init__(self, staff_id, name, department):
        self.staff_id = staff_id
        self.name = name
        self.department = department
        self.training_history = []

    def attend_training(self, event):
        self.training_history.append(event)

class TrainingTracker:
    def __init__(self):
        self.training_events = []
        self.staff_records = {}

    def add_training_event(self, event):
        self.training_events.append(event)

    def add_staff(self, staff):
        self.staff_records[staff.staff_id] = staff

    def assign_training_to_staff(self, staff_id, event_id):
        if staff_id in self.staff_records and event_id in [event.event_id for event in self.training_events]:
            staff = self.staff_records[staff_id]
            event = next(event for event in self.training_events if event.event_id == event_id)
            staff.attend_training(event)
            print(f"{staff.name} attended the {event.event_name} training.")
        else:
            print("Invalid staff ID or event ID.")

    def display_staff_training_history(self, staff_id):
        if staff_id in self.staff_records:
            staff = self.staff_records[staff_id]
            print(f"Training History for {staff.name}:")
            for event in staff.training_history:
                print(f"Event ID: {event.event_id}, Event Name: {event.event_name}, Date: {event.date}, Duration: {event.duration_hours} hours, Location: {event.location}")
        else:
            print("Staff not found.")
